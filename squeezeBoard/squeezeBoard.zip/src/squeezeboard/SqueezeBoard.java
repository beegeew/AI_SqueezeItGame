//Fall 2011 Squeeze-It game 
//CS3368 - Artificial Intelligence
//Jordan Littlejohn
//Beverly Wertz

package squeezeboard;

//Main project class that creates and displays our board
public class SqueezeBoard {

    //main function creates a new board and displays it
    public static void main(String args[]) {
        sqBoard squeezeBoard = new sqBoard();
        squeezeBoard.setVisible(true);
    }
}
